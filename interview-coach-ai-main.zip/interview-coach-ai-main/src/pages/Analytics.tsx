import React, { useState, useEffect, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
} from "recharts";
import {
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  Target,
  Clock,
  Zap,
  BookOpen,
  Loader2,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Progress } from "@/components/ui/progress";

interface AnswerWithQuestion {
  id: string;
  answer: string;
  is_correct: boolean;
  time_taken_seconds: number | null;
  created_at: string;
  question_id: string;
  question?: {
    category: string;
    difficulty: string;
    title: string;
    type: string;
  };
}

interface TopicStat {
  topic: string;
  total: number;
  correct: number;
  accuracy: number;
  avgTime: number;
  trend: number; // positive = improving
  recentAccuracy: number;
  difficulties: { easy: number; medium: number; hard: number };
}

const Analytics = () => {
  const { user } = useAuth();
  const [answers, setAnswers] = useState<AnswerWithQuestion[]>([]);
  const [loading, setLoading] = useState(true);
  const [expandedTopic, setExpandedTopic] = useState<string | null>(null);
  const [drillDownView, setDrillDownView] = useState<"strengths" | "weaknesses">("weaknesses");

  useEffect(() => {
    if (!user) return;
    const fetchData = async () => {
      setLoading(true);
      const { data: answersData } = await supabase
        .from("user_answers")
        .select("id, answer, is_correct, time_taken_seconds, created_at, question_id")
        .eq("user_id", user.id)
        .order("created_at", { ascending: true });

      if (answersData && answersData.length > 0) {
        const questionIds = [...new Set(answersData.map((a) => a.question_id))];
        const { data: questionsData } = await supabase
          .from("questions")
          .select("id, category, difficulty, title, type")
          .in("id", questionIds);

        const qMap = new Map(questionsData?.map((q) => [q.id, q]) || []);
        const merged = answersData.map((a) => ({
          ...a,
          question: qMap.get(a.question_id),
        }));
        setAnswers(merged);
      } else {
        setAnswers([]);
      }
      setLoading(false);
    };
    fetchData();
  }, [user]);

  const topicStats = useMemo((): TopicStat[] => {
    const map = new Map<string, AnswerWithQuestion[]>();
    answers.forEach((a) => {
      const cat = a.question?.category || "Unknown";
      if (!map.has(cat)) map.set(cat, []);
      map.get(cat)!.push(a);
    });

    return Array.from(map.entries()).map(([topic, items]) => {
      const total = items.length;
      const correct = items.filter((i) => i.is_correct).length;
      const accuracy = total > 0 ? Math.round((correct / total) * 100) : 0;
      const avgTime = Math.round(
        items.reduce((s, i) => s + (i.time_taken_seconds || 0), 0) / total
      );

      // Recent vs older for trend
      const half = Math.floor(total / 2);
      const older = items.slice(0, half);
      const recent = items.slice(half);
      const olderAcc = older.length > 0 ? older.filter((i) => i.is_correct).length / older.length * 100 : 0;
      const recentAcc = recent.length > 0 ? recent.filter((i) => i.is_correct).length / recent.length * 100 : 0;

      const difficulties = { easy: 0, medium: 0, hard: 0 };
      items.forEach((i) => {
        const d = (i.question?.difficulty || "easy").toLowerCase() as "easy" | "medium" | "hard";
        if (d in difficulties) difficulties[d]++;
      });

      return { topic, total, correct, accuracy, avgTime, trend: Math.round(recentAcc - olderAcc), recentAccuracy: Math.round(recentAcc), difficulties };
    });
  }, [answers]);

  const radarData = topicStats.map((t) => ({ subject: t.topic, score: t.accuracy }));
  const strengths = useMemo(() => [...topicStats].filter((t) => t.accuracy >= 70).sort((a, b) => b.accuracy - a.accuracy), [topicStats]);
  const weaknesses = useMemo(() => [...topicStats].filter((t) => t.accuracy < 70).sort((a, b) => a.accuracy - b.accuracy), [topicStats]);

  const overallAccuracy = answers.length > 0
    ? Math.round((answers.filter((a) => a.is_correct).length / answers.length) * 100)
    : 0;

  const difficultyBreakdown = useMemo(() => {
    const counts = { Easy: 0, Medium: 0, Hard: 0 };
    answers.forEach((a) => {
      const d = a.question?.difficulty || "Easy";
      const key = d.charAt(0).toUpperCase() + d.slice(1).toLowerCase();
      if (key in counts) counts[key as keyof typeof counts]++;
    });
    return [
      { name: "Easy", value: counts.Easy, color: "hsl(var(--success))" },
      { name: "Medium", value: counts.Medium, color: "hsl(var(--warning))" },
      { name: "Hard", value: counts.Hard, color: "hsl(var(--destructive))" },
    ].filter((d) => d.value > 0);
  }, [answers]);

  // Weekly activity from answers
  const weeklyData = useMemo(() => {
    if (answers.length === 0) return [];
    const weeks = new Map<string, { questions: number; correct: number }>();
    answers.forEach((a) => {
      const d = new Date(a.created_at);
      const weekStart = new Date(d);
      weekStart.setDate(d.getDate() - d.getDay());
      const key = weekStart.toISOString().slice(0, 10);
      if (!weeks.has(key)) weeks.set(key, { questions: 0, correct: 0 });
      const w = weeks.get(key)!;
      w.questions++;
      if (a.is_correct) w.correct++;
    });
    return Array.from(weeks.entries())
      .sort(([a], [b]) => a.localeCompare(b))
      .slice(-8)
      .map(([week, data]) => ({
        week: new Date(week).toLocaleDateString("en", { month: "short", day: "numeric" }),
        questions: data.questions,
        accuracy: data.questions > 0 ? Math.round((data.correct / data.questions) * 100) : 0,
      }));
  }, [answers]);

  const improvementScore = useMemo(() => {
    if (answers.length < 4) return 0;
    const half = Math.floor(answers.length / 2);
    const first = answers.slice(0, half);
    const second = answers.slice(half);
    const firstAcc = first.filter((a) => a.is_correct).length / first.length * 100;
    const secondAcc = second.filter((a) => a.is_correct).length / second.length * 100;
    return Math.round(secondAcc - firstAcc);
  }, [answers]);

  // Use mock data if no real data
  const hasMockData = answers.length === 0;
  const displayRadar = hasMockData
    ? [{ subject: "DSA", score: 78 }, { subject: "System Design", score: 65 }, { subject: "HR", score: 90 }, { subject: "Aptitude", score: 72 }]
    : radarData;
  const displayWeekly = hasMockData
    ? [{ week: "W1", questions: 18, accuracy: 72 }, { week: "W2", questions: 25, accuracy: 76 }, { week: "W3", questions: 22, accuracy: 74 }, { week: "W4", questions: 30, accuracy: 80 }]
    : weeklyData;
  const displayDifficulty = hasMockData
    ? [{ name: "Easy", value: 45, color: "hsl(var(--success))" }, { name: "Medium", value: 35, color: "hsl(var(--warning))" }, { name: "Hard", value: 20, color: "hsl(var(--destructive))" }]
    : difficultyBreakdown;
  const displayStrengths = hasMockData
    ? [{ topic: "Arrays & Strings", accuracy: 92, total: 24, correct: 22, avgTime: 45, trend: 8, recentAccuracy: 95, difficulties: { easy: 10, medium: 10, hard: 4 } },
       { topic: "HR Communication", accuracy: 88, total: 16, correct: 14, avgTime: 30, trend: 5, recentAccuracy: 90, difficulties: { easy: 8, medium: 6, hard: 2 } },
       { topic: "Basic Probability", accuracy: 80, total: 10, correct: 8, avgTime: 55, trend: 3, recentAccuracy: 83, difficulties: { easy: 5, medium: 3, hard: 2 } }] as TopicStat[]
    : strengths;
  const displayWeaknesses = hasMockData
    ? [{ topic: "Dynamic Programming", accuracy: 42, total: 19, correct: 8, avgTime: 120, trend: -5, recentAccuracy: 38, difficulties: { easy: 3, medium: 8, hard: 8 } },
       { topic: "Graph Algorithms", accuracy: 50, total: 14, correct: 7, avgTime: 95, trend: 2, recentAccuracy: 55, difficulties: { easy: 2, medium: 6, hard: 6 } },
       { topic: "System Design Trade-offs", accuracy: 55, total: 11, correct: 6, avgTime: 80, trend: -2, recentAccuracy: 50, difficulties: { easy: 1, medium: 5, hard: 5 } }] as TopicStat[]
    : weaknesses;

  if (loading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  const TopicDrillDown = ({ topic, isStrength }: { topic: TopicStat; isStrength: boolean }) => {
    const isOpen = expandedTopic === topic.topic;
    const accentColor = isStrength ? "success" : "destructive";

    return (
      <motion.div
        layout
        className="glass overflow-hidden rounded-xl"
      >
        <button
          onClick={() => setExpandedTopic(isOpen ? null : topic.topic)}
          className="flex w-full items-center gap-4 p-4 text-left transition-colors hover:bg-accent/30"
        >
          <div className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-${accentColor}/10`}>
            {isStrength ? (
              <CheckCircle2 className={`h-5 w-5 text-${accentColor}`} />
            ) : (
              <AlertTriangle className={`h-5 w-5 text-${accentColor}`} />
            )}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <p className="font-medium text-foreground truncate">{topic.topic}</p>
              <div className="flex items-center gap-2 ml-2">
                <span className={`text-sm font-semibold ${isStrength ? "text-success" : "text-destructive"}`}>
                  {topic.accuracy}%
                </span>
                {topic.trend !== 0 && (
                  <span className={`flex items-center text-xs ${topic.trend > 0 ? "text-success" : "text-destructive"}`}>
                    {topic.trend > 0 ? <TrendingUp className="h-3 w-3 mr-0.5" /> : <TrendingDown className="h-3 w-3 mr-0.5" />}
                    {Math.abs(topic.trend)}%
                  </span>
                )}
              </div>
            </div>
            <Progress value={topic.accuracy} className="mt-2 h-1.5" />
          </div>
          <div className="shrink-0 ml-2">
            {isOpen ? <ChevronDown className="h-4 w-4 text-muted-foreground" /> : <ChevronRight className="h-4 w-4 text-muted-foreground" />}
          </div>
        </button>

        <AnimatePresence>
          {isOpen && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="overflow-hidden"
            >
              <div className="border-t border-border/50 p-4 space-y-4">
                {/* Stats grid */}
                <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                  <div className="rounded-lg bg-muted/50 p-3 text-center">
                    <Target className="mx-auto mb-1 h-4 w-4 text-muted-foreground" />
                    <p className="text-lg font-semibold text-foreground">{topic.correct}/{topic.total}</p>
                    <p className="text-xs text-muted-foreground">Correct</p>
                  </div>
                  <div className="rounded-lg bg-muted/50 p-3 text-center">
                    <Clock className="mx-auto mb-1 h-4 w-4 text-muted-foreground" />
                    <p className="text-lg font-semibold text-foreground">{topic.avgTime}s</p>
                    <p className="text-xs text-muted-foreground">Avg Time</p>
                  </div>
                  <div className="rounded-lg bg-muted/50 p-3 text-center">
                    <Zap className="mx-auto mb-1 h-4 w-4 text-muted-foreground" />
                    <p className="text-lg font-semibold text-foreground">{topic.recentAccuracy}%</p>
                    <p className="text-xs text-muted-foreground">Recent Acc.</p>
                  </div>
                  <div className="rounded-lg bg-muted/50 p-3 text-center">
                    <BookOpen className="mx-auto mb-1 h-4 w-4 text-muted-foreground" />
                    <p className="text-lg font-semibold text-foreground">{topic.total}</p>
                    <p className="text-xs text-muted-foreground">Attempted</p>
                  </div>
                </div>

                {/* Difficulty distribution */}
                <div>
                  <p className="mb-2 text-sm font-medium text-muted-foreground">Difficulty Distribution</p>
                  <div className="flex gap-2">
                    {[
                      { label: "Easy", count: topic.difficulties.easy, color: "bg-success/20 text-success" },
                      { label: "Medium", count: topic.difficulties.medium, color: "bg-warning/20 text-warning" },
                      { label: "Hard", count: topic.difficulties.hard, color: "bg-destructive/20 text-destructive" },
                    ].map((d) => (
                      <div key={d.label} className={`flex-1 rounded-lg p-2.5 text-center ${d.color}`}>
                        <p className="text-base font-semibold">{d.count}</p>
                        <p className="text-xs opacity-80">{d.label}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Recommendation */}
                <div className="rounded-lg border border-border/50 bg-muted/30 p-3">
                  <p className="text-xs font-medium text-muted-foreground mb-1">💡 Recommendation</p>
                  <p className="text-sm text-foreground">
                    {isStrength
                      ? `Great work on ${topic.topic}! Try tackling more Hard-level problems to push your mastery further.`
                      : topic.accuracy < 50
                        ? `Focus on fundamentals of ${topic.topic}. Start with Easy problems and build up gradually.`
                        : `You're close to mastering ${topic.topic}! Review your mistakes on Medium-level questions for the biggest improvement.`}
                  </p>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    );
  };

  return (
    <div className="space-y-8">
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-2xl font-semibold text-foreground">Analytics</h1>
        <p className="mt-1 text-muted-foreground">
          Deep insights into your preparation progress
          {hasMockData && <span className="ml-2 text-xs text-warning">(showing sample data — solve questions to see your stats)</span>}
        </p>
      </motion.div>

      {/* Top insights */}
      <div className="grid gap-4 sm:grid-cols-3">
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="glass rounded-2xl p-5">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-success/10">
              <TrendingUp className="h-5 w-5 text-success" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Improvement Score</p>
              <p className="text-2xl font-semibold text-foreground">
                {hasMockData ? "+12" : (improvementScore >= 0 ? "+" : "") + improvementScore}%
              </p>
            </div>
          </div>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="glass rounded-2xl p-5">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10">
              <Target className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Overall Accuracy</p>
              <p className="text-2xl font-semibold text-foreground">{hasMockData ? 76 : overallAccuracy}%</p>
            </div>
          </div>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="glass rounded-2xl p-5">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-accent/50">
              <BookOpen className="h-5 w-5 text-foreground" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Questions Solved</p>
              <p className="text-2xl font-semibold text-foreground">{hasMockData ? 94 : answers.length}</p>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Topic Strengths & Weaknesses Drill-Down */}
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.25 }}>
        <div className="mb-4 flex items-center gap-2">
          <h2 className="text-lg font-semibold text-foreground">Topic Drill-Down</h2>
          <div className="ml-auto flex rounded-full border border-border/50 bg-muted/50 p-1">
            <button
              onClick={() => setDrillDownView("weaknesses")}
              className={`rounded-full px-3 py-1 text-xs font-medium transition-all ${
                drillDownView === "weaknesses"
                  ? "bg-background text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <AlertTriangle className="mr-1 inline h-3 w-3" />
              Weaknesses ({displayWeaknesses.length})
            </button>
            <button
              onClick={() => setDrillDownView("strengths")}
              className={`rounded-full px-3 py-1 text-xs font-medium transition-all ${
                drillDownView === "strengths"
                  ? "bg-background text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <CheckCircle2 className="mr-1 inline h-3 w-3" />
              Strengths ({displayStrengths.length})
            </button>
          </div>
        </div>

        <div className="space-y-2">
          <AnimatePresence mode="wait">
            {drillDownView === "weaknesses" ? (
              <motion.div key="weak" initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 10 }} className="space-y-2">
                {displayWeaknesses.length === 0 ? (
                  <div className="glass rounded-xl p-8 text-center">
                    <CheckCircle2 className="mx-auto mb-2 h-8 w-8 text-success" />
                    <p className="text-muted-foreground">No weak areas detected — great job!</p>
                  </div>
                ) : (
                  displayWeaknesses.map((t) => <TopicDrillDown key={t.topic} topic={t} isStrength={false} />)
                )}
              </motion.div>
            ) : (
              <motion.div key="strong" initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -10 }} className="space-y-2">
                {displayStrengths.length === 0 ? (
                  <div className="glass rounded-xl p-8 text-center">
                    <Target className="mx-auto mb-2 h-8 w-8 text-muted-foreground" />
                    <p className="text-muted-foreground">Keep practicing to build your strengths!</p>
                  </div>
                ) : (
                  displayStrengths.map((t) => <TopicDrillDown key={t.topic} topic={t} isStrength={true} />)
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>

      {/* Charts */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* Radar */}
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="glass rounded-2xl p-6">
          <h3 className="mb-4 text-base font-semibold text-foreground">Category Performance</h3>
          <ResponsiveContainer width="100%" height={280}>
            <RadarChart data={displayRadar}>
              <PolarGrid stroke="hsl(var(--border))" />
              <PolarAngleAxis dataKey="subject" tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }} />
              <PolarRadiusAxis domain={[0, 100]} tick={{ fontSize: 10 }} />
              <Radar dataKey="score" stroke="hsl(var(--primary))" fill="hsl(var(--primary))" fillOpacity={0.2} />
            </RadarChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Weekly activity */}
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.35 }} className="glass rounded-2xl p-6">
          <h3 className="mb-4 text-base font-semibold text-foreground">Weekly Activity</h3>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={displayWeekly}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="week" stroke="hsl(var(--muted-foreground))" fontSize={12} />
              <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
              <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: "8px", fontSize: "12px" }} />
              <Bar dataKey="questions" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Accuracy trend line */}
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }} className="glass rounded-2xl p-6">
          <h3 className="mb-4 text-base font-semibold text-foreground">Accuracy Trend</h3>
          <ResponsiveContainer width="100%" height={280}>
            <LineChart data={displayWeekly}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="week" stroke="hsl(var(--muted-foreground))" fontSize={12} />
              <YAxis domain={[0, 100]} stroke="hsl(var(--muted-foreground))" fontSize={12} />
              <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: "8px", fontSize: "12px" }} />
              <Line type="monotone" dataKey="accuracy" stroke="hsl(var(--primary))" strokeWidth={2} dot={{ fill: "hsl(var(--primary))", r: 4 }} />
            </LineChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Pie */}
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.45 }} className="glass rounded-2xl p-6">
          <h3 className="mb-4 text-base font-semibold text-foreground">Difficulty Breakdown</h3>
          <ResponsiveContainer width="100%" height={280}>
            <PieChart>
              <Pie data={displayDifficulty} cx="50%" cy="50%" innerRadius={60} outerRadius={100} dataKey="value" label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}>
                {displayDifficulty.map((entry, i) => (
                  <Cell key={i} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: "8px", fontSize: "12px" }} />
            </PieChart>
          </ResponsiveContainer>
        </motion.div>
      </div>
    </div>
  );
};

export default Analytics;

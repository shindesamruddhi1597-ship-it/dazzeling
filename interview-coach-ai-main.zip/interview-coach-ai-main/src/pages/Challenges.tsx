import React from "react";
import { motion } from "framer-motion";
import { Trophy, Medal, Clock, Target } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

const dailyChallenge = {
  title: "Optimize a Search Algorithm",
  description: "Given a sorted array, implement a search that runs in O(log n) time.",
  difficulty: "medium",
  timeLimit: "15 min",
  points: 50,
  participants: 234,
};

const leaderboard = [
  { rank: 1, name: "Alice Chen", points: 2840, accuracy: 94 },
  { rank: 2, name: "Raj Patel", points: 2720, accuracy: 91 },
  { rank: 3, name: "Sarah Kim", points: 2650, accuracy: 89 },
  { rank: 4, name: "James Wu", points: 2580, accuracy: 87 },
  { rank: 5, name: "Priya Sharma", points: 2510, accuracy: 85 },
  { rank: 6, name: "David Park", points: 2440, accuracy: 84 },
  { rank: 7, name: "Emma Liu", points: 2370, accuracy: 82 },
  { rank: 8, name: "Michael Torres", points: 2300, accuracy: 80 },
];

const Challenges = () => {
  return (
    <div className="space-y-8">
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-2xl font-semibold text-foreground">Challenges</h1>
        <p className="mt-1 text-muted-foreground">Compete daily and climb the leaderboard</p>
      </motion.div>

      {/* Daily Challenge */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="glass rounded-2xl p-6"
      >
        <div className="flex items-start justify-between">
          <div>
            <div className="mb-3 flex items-center gap-2">
              <Badge className="border border-warning/20 bg-warning/10 text-warning">Daily Challenge</Badge>
              <Badge variant="secondary">{dailyChallenge.difficulty}</Badge>
            </div>
            <h2 className="text-lg font-semibold text-foreground">{dailyChallenge.title}</h2>
            <p className="mt-2 text-sm text-muted-foreground">{dailyChallenge.description}</p>
            <div className="mt-4 flex items-center gap-4 text-xs text-muted-foreground">
              <span className="flex items-center gap-1"><Clock className="h-3.5 w-3.5" /> {dailyChallenge.timeLimit}</span>
              <span className="flex items-center gap-1"><Target className="h-3.5 w-3.5" /> {dailyChallenge.points} pts</span>
              <span>{dailyChallenge.participants} participants</span>
            </div>
          </div>
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-accent">
            <Trophy className="h-6 w-6 text-primary" />
          </div>
        </div>
      </motion.div>

      {/* Leaderboard */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="glass rounded-2xl p-6"
      >
        <h3 className="mb-4 text-base font-semibold text-foreground">Leaderboard</h3>
        <div className="space-y-2">
          {leaderboard.map((entry, i) => (
            <motion.div
              key={entry.rank}
              initial={{ opacity: 0, x: -8 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.05 * i }}
              className={cn(
                "flex items-center gap-4 rounded-xl px-4 py-3 transition-colors",
                entry.rank <= 3 ? "bg-accent/50" : "hover:bg-muted/50"
              )}
            >
              <div className={cn(
                "flex h-8 w-8 items-center justify-center rounded-full text-sm font-semibold",
                entry.rank === 1 && "bg-warning text-warning-foreground",
                entry.rank === 2 && "bg-muted text-muted-foreground",
                entry.rank === 3 && "bg-warning/50 text-foreground",
                entry.rank > 3 && "bg-secondary text-secondary-foreground"
              )}>
                {entry.rank <= 3 ? <Medal className="h-4 w-4" /> : entry.rank}
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-foreground">{entry.name}</p>
              </div>
              <div className="text-right">
                <p className="text-sm font-semibold text-foreground">{entry.points.toLocaleString()} pts</p>
                <p className="text-xs text-muted-foreground">{entry.accuracy}% accuracy</p>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </div>
  );
};

export default Challenges;

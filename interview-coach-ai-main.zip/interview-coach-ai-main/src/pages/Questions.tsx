import React, { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import {
  Code2,
  Layout,
  Users,
  Brain,
  Clock,
  CheckCircle2,
  XCircle,
  ChevronRight,
} from "lucide-react";

const categories = [
  { id: "all", label: "All", icon: null },
  { id: "dsa", label: "DSA", icon: Code2 },
  { id: "system_design", label: "System Design", icon: Layout },
  { id: "hr", label: "HR", icon: Users },
  { id: "aptitude", label: "Aptitude", icon: Brain },
];

const difficulties = ["all", "easy", "medium", "hard"] as const;

// Sample questions
const sampleQuestions = [
  {
    id: "1",
    title: "Two Sum Problem",
    category: "dsa",
    difficulty: "easy",
    type: "mcq",
    description: "Given an array of integers, return indices of the two numbers such that they add up to a specific target.",
    options: ["O(n²) brute force", "Hash map O(n)", "Sorting O(n log n)", "Binary search O(n log n)"],
    correct_answer: "Hash map O(n)",
    explanation: "Using a hash map allows us to look up the complement of each number in O(1) time.",
  },
  {
    id: "2",
    title: "Design a URL Shortener",
    category: "system_design",
    difficulty: "medium",
    type: "subjective",
    description: "Design a system like bit.ly that shortens long URLs. Discuss scalability, database choice, and caching strategy.",
  },
  {
    id: "3",
    title: "Tell me about yourself",
    category: "hr",
    difficulty: "easy",
    type: "subjective",
    description: "Craft a compelling 2-minute introduction that highlights your experience, skills, and career goals.",
  },
  {
    id: "4",
    title: "Probability of Rolling Sum",
    category: "aptitude",
    difficulty: "medium",
    type: "mcq",
    description: "What is the probability of getting a sum of 7 when rolling two dice?",
    options: ["1/6", "1/12", "5/36", "7/36"],
    correct_answer: "1/6",
    explanation: "There are 6 ways to get sum 7 out of 36 total outcomes: 6/36 = 1/6.",
  },
  {
    id: "5",
    title: "Reverse a Linked List",
    category: "dsa",
    difficulty: "medium",
    type: "mcq",
    description: "What is the optimal approach to reverse a singly linked list?",
    options: ["Stack-based O(n) space", "Iterative three-pointer O(1) space", "Recursive O(n) space", "Copy to array and reverse"],
    correct_answer: "Iterative three-pointer O(1) space",
    explanation: "The iterative approach using three pointers (prev, curr, next) reverses the list in O(n) time and O(1) space.",
  },
  {
    id: "6",
    title: "Design a Chat System",
    category: "system_design",
    difficulty: "hard",
    type: "subjective",
    description: "Design a real-time chat application like WhatsApp. Discuss WebSocket connections, message delivery guarantees, and offline support.",
  },
];

const Questions = () => {
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>("all");
  const [activeQuestion, setActiveQuestion] = useState<typeof sampleQuestions[0] | null>(null);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [subjectiveAnswer, setSubjectiveAnswer] = useState("");

  const filtered = sampleQuestions.filter(
    (q) =>
      (selectedCategory === "all" || q.category === selectedCategory) &&
      (selectedDifficulty === "all" || q.difficulty === selectedDifficulty)
  );

  const handleSubmitAnswer = () => {
    if (activeQuestion?.type === "mcq" && selectedAnswer) {
      setShowResult(true);
    }
  };

  const handleBack = () => {
    setActiveQuestion(null);
    setSelectedAnswer(null);
    setShowResult(false);
    setSubjectiveAnswer("");
  };

  const difficultyColor = (d: string) => {
    switch (d) {
      case "easy": return "bg-success/10 text-success border-success/20";
      case "medium": return "bg-warning/10 text-warning border-warning/20";
      case "hard": return "bg-destructive/10 text-destructive border-destructive/20";
      default: return "";
    }
  };

  // Question detail view
  if (activeQuestion) {
    return (
      <div className="space-y-6">
        <button onClick={handleBack} className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors">
          ← Back to questions
        </button>

        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="glass rounded-2xl p-6">
          <div className="mb-4 flex items-center gap-3">
            <Badge className={cn("border", difficultyColor(activeQuestion.difficulty))}>
              {activeQuestion.difficulty}
            </Badge>
            <Badge variant="secondary">{activeQuestion.category.replace("_", " ")}</Badge>
          </div>
          <h2 className="text-xl font-semibold text-foreground">{activeQuestion.title}</h2>
          <p className="mt-3 text-muted-foreground leading-relaxed">{activeQuestion.description}</p>

          {/* MCQ options */}
          {activeQuestion.type === "mcq" && activeQuestion.options && (
            <div className="mt-6 space-y-3">
              {activeQuestion.options.map((opt, i) => (
                <button
                  key={i}
                  onClick={() => !showResult && setSelectedAnswer(opt)}
                  className={cn(
                    "w-full rounded-xl border p-4 text-left text-sm transition-all",
                    selectedAnswer === opt && !showResult && "border-primary bg-accent",
                    showResult && opt === activeQuestion.correct_answer && "border-success bg-success/10",
                    showResult && selectedAnswer === opt && opt !== activeQuestion.correct_answer && "border-destructive bg-destructive/10",
                    !showResult && selectedAnswer !== opt && "border-border hover:border-muted-foreground/30"
                  )}
                >
                  <div className="flex items-center gap-3">
                    <span className="flex h-6 w-6 items-center justify-center rounded-full border text-xs font-medium">
                      {String.fromCharCode(65 + i)}
                    </span>
                    <span className="text-foreground">{opt}</span>
                    {showResult && opt === activeQuestion.correct_answer && <CheckCircle2 className="ml-auto h-5 w-5 text-success" />}
                    {showResult && selectedAnswer === opt && opt !== activeQuestion.correct_answer && <XCircle className="ml-auto h-5 w-5 text-destructive" />}
                  </div>
                </button>
              ))}

              {!showResult ? (
                <Button onClick={handleSubmitAnswer} disabled={!selectedAnswer} className="mt-4">
                  Submit Answer
                </Button>
              ) : (
                <div className="mt-4 rounded-xl border border-border bg-muted/50 p-4">
                  <p className="text-sm font-medium text-foreground">Explanation</p>
                  <p className="mt-1 text-sm text-muted-foreground">{activeQuestion.explanation}</p>
                </div>
              )}
            </div>
          )}

          {/* Subjective */}
          {activeQuestion.type === "subjective" && (
            <div className="mt-6">
              <textarea
                value={subjectiveAnswer}
                onChange={(e) => setSubjectiveAnswer(e.target.value)}
                placeholder="Type your answer here..."
                className="w-full rounded-xl border border-border bg-background p-4 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring min-h-[150px] resize-y"
              />
              <Button className="mt-3" disabled={!subjectiveAnswer.trim()}>
                Submit Answer
              </Button>
            </div>
          )}
        </motion.div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-2xl font-semibold text-foreground">Questions</h1>
        <p className="mt-1 text-muted-foreground">Practice across categories and difficulty levels</p>
      </motion.div>

      {/* Filters */}
      <div className="space-y-3">
        <div className="flex flex-wrap gap-2">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={cn(
                "flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
                selectedCategory === cat.id
                  ? "bg-primary text-primary-foreground"
                  : "bg-secondary text-secondary-foreground hover:bg-accent"
              )}
            >
              {cat.icon && <cat.icon className="h-3.5 w-3.5" />}
              {cat.label}
            </button>
          ))}
        </div>
        <div className="flex gap-2">
          {difficulties.map((d) => (
            <button
              key={d}
              onClick={() => setSelectedDifficulty(d)}
              className={cn(
                "rounded-md px-3 py-1.5 text-xs font-medium capitalize transition-colors",
                selectedDifficulty === d
                  ? "bg-foreground text-background"
                  : "bg-secondary text-secondary-foreground hover:bg-accent"
              )}
            >
              {d}
            </button>
          ))}
        </div>
      </div>

      {/* Questions list */}
      <div className="space-y-3">
        {filtered.map((q, i) => (
          <motion.button
            key={q.id}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
            onClick={() => setActiveQuestion(q)}
            className="glass w-full rounded-xl p-4 text-left transition-all hover:shadow-md"
          >
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <div className="mb-2 flex items-center gap-2">
                  <Badge className={cn("border text-xs", difficultyColor(q.difficulty))}>
                    {q.difficulty}
                  </Badge>
                  <Badge variant="outline" className="text-xs">
                    {q.category.replace("_", " ")}
                  </Badge>
                  <Badge variant="outline" className="text-xs">
                    {q.type === "mcq" ? "MCQ" : "Subjective"}
                  </Badge>
                </div>
                <h3 className="text-sm font-medium text-foreground">{q.title}</h3>
                <p className="mt-1 text-xs text-muted-foreground line-clamp-1">{q.description}</p>
              </div>
              <ChevronRight className="ml-4 h-4 w-4 text-muted-foreground" />
            </div>
          </motion.button>
        ))}
      </div>
    </div>
  );
};

export default Questions;

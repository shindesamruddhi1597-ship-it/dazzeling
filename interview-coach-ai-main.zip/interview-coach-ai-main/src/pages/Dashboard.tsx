import React, { useEffect, useState, useMemo } from "react";
import { motion } from "framer-motion";
import {
  CheckCircle2,
  Target,
  Flame,
  MessageSquare,
  Trophy,
  TrendingUp,
  TrendingDown,
  Clock,
  Zap,
  Lightbulb,
  BookOpen,
  ArrowRight,
  Circle,
  Loader2,
} from "lucide-react";
import StatCard from "@/components/StatCard";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  AreaChart,
  Area,
} from "recharts";

interface AnswerRecord {
  id: string;
  is_correct: boolean;
  created_at: string;
  time_taken_seconds: number | null;
  question_id: string;
}

interface QuestionRecord {
  id: string;
  category: string;
  difficulty: string;
  title: string;
}

// Milestone definitions
const milestones = [
  { target: 1, label: "First Question", icon: "🎯" },
  { target: 10, label: "10 Questions Solved", icon: "📝" },
  { target: 25, label: "25 Questions Solved", icon: "🚀" },
  { target: 50, label: "50 Questions Solved", icon: "⭐" },
  { target: 100, label: "Century Club", icon: "💯" },
  { target: 250, label: "Master Level", icon: "🏆" },
];

const Dashboard = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [profile, setProfile] = useState<any>(null);
  const [answers, setAnswers] = useState<AnswerRecord[]>([]);
  const [questions, setQuestions] = useState<QuestionRecord[]>([]);
  const [chatCount, setChatCount] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    const fetchAll = async () => {
      const [profileRes, answersRes, chatsRes] = await Promise.all([
        supabase.from("profiles").select("*").eq("user_id", user.id).single(),
        supabase.from("user_answers").select("id, is_correct, created_at, time_taken_seconds, question_id").eq("user_id", user.id).order("created_at", { ascending: true }),
        supabase.from("chat_history").select("id", { count: "exact", head: true }).eq("user_id", user.id),
      ]);
      setProfile(profileRes.data);
      const ans = answersRes.data || [];
      setAnswers(ans);
      setChatCount(chatsRes.count || 0);

      if (ans.length > 0) {
        const qIds = [...new Set(ans.map((a) => a.question_id))];
        const { data: qData } = await supabase.from("questions").select("id, category, difficulty, title").in("id", qIds);
        setQuestions(qData || []);
      }
      setLoading(false);
    };
    fetchAll();
  }, [user]);

  const qMap = useMemo(() => new Map(questions.map((q) => [q.id, q])), [questions]);

  const totalSolved = answers.length;
  const correctCount = answers.filter((a) => a.is_correct).length;
  const accuracy = totalSolved > 0 ? Math.round((correctCount / totalSolved) * 100) : 0;

  // Weekly data from real answers
  const weeklyData = useMemo(() => {
    const now = new Date();
    const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    const weekStart = new Date(now);
    weekStart.setDate(now.getDate() - now.getDay());
    weekStart.setHours(0, 0, 0, 0);

    const result = days.map((day) => ({ day, solved: 0, correct: 0 }));
    answers.forEach((a) => {
      const d = new Date(a.created_at);
      if (d >= weekStart) {
        const idx = d.getDay();
        result[idx].solved++;
        if (a.is_correct) result[idx].correct++;
      }
    });
    // Reorder starting from Monday
    return [...result.slice(1), result[0]];
  }, [answers]);

  // Category accuracy
  const categoryData = useMemo(() => {
    const map = new Map<string, { total: number; correct: number }>();
    answers.forEach((a) => {
      const cat = qMap.get(a.question_id)?.category || "Unknown";
      if (!map.has(cat)) map.set(cat, { total: 0, correct: 0 });
      const e = map.get(cat)!;
      e.total++;
      if (a.is_correct) e.correct++;
    });
    return Array.from(map.entries()).map(([name, d]) => ({
      name,
      accuracy: d.total > 0 ? Math.round((d.correct / d.total) * 100) : 0,
      total: d.total,
    }));
  }, [answers, qMap]);

  // Accuracy over time (cumulative)
  const accuracyTimeline = useMemo(() => {
    if (answers.length === 0) return [];
    const points: { index: number; accuracy: number }[] = [];
    let correct = 0;
    answers.forEach((a, i) => {
      if (a.is_correct) correct++;
      if ((i + 1) % Math.max(1, Math.floor(answers.length / 12)) === 0 || i === answers.length - 1) {
        points.push({ index: i + 1, accuracy: Math.round((correct / (i + 1)) * 100) });
      }
    });
    return points;
  }, [answers]);

  // Improvement score
  const improvementScore = useMemo(() => {
    if (answers.length < 6) return null;
    const half = Math.floor(answers.length / 2);
    const firstHalf = answers.slice(0, half);
    const secondHalf = answers.slice(half);
    const firstAcc = firstHalf.filter((a) => a.is_correct).length / firstHalf.length * 100;
    const secondAcc = secondHalf.filter((a) => a.is_correct).length / secondHalf.length * 100;
    return Math.round(secondAcc - firstAcc);
  }, [answers]);

  // Recent activity timeline
  const recentActivity = useMemo(() => {
    return answers.slice(-8).reverse().map((a) => ({
      ...a,
      question: qMap.get(a.question_id),
    }));
  }, [answers, qMap]);

  // Weak & strong categories for suggestions
  const suggestions = useMemo(() => {
    const tips: { type: "warning" | "success" | "info"; text: string }[] = [];
    categoryData.forEach((c) => {
      if (c.accuracy < 50 && c.total >= 3) {
        tips.push({ type: "warning", text: `Your ${c.name} accuracy is ${c.accuracy}%. Focus on fundamentals and practice easy problems first.` });
      } else if (c.accuracy >= 85 && c.total >= 5) {
        tips.push({ type: "success", text: `Excellent ${c.name} performance (${c.accuracy}%)! Try harder difficulty to push your limits.` });
      }
    });
    if (totalSolved > 0 && totalSolved < 10) {
      tips.push({ type: "info", text: "Build consistency — aim for at least 5 questions per day to develop strong habits." });
    }
    if (improvementScore !== null && improvementScore < 0) {
      tips.push({ type: "warning", text: "Your recent accuracy is declining. Take a break or revisit topics you've previously mastered." });
    }
    if (improvementScore !== null && improvementScore > 10) {
      tips.push({ type: "success", text: `Amazing improvement of +${improvementScore}%! Keep this momentum going.` });
    }
    if (chatCount === 0) {
      tips.push({ type: "info", text: "Try the AI Chat to get personalized explanations and mock interview practice." });
    }
    if (tips.length === 0) {
      tips.push({ type: "info", text: "Keep practicing consistently! Aim for a balanced mix across all categories." });
    }
    return tips;
  }, [categoryData, totalSolved, improvementScore, chatCount]);

  // Use mock data when no real data
  const hasMock = answers.length === 0;
  const mockWeekly = [
    { day: "Mon", solved: 5, correct: 4 },
    { day: "Tue", solved: 8, correct: 6 },
    { day: "Wed", solved: 3, correct: 2 },
    { day: "Thu", solved: 12, correct: 10 },
    { day: "Fri", solved: 7, correct: 5 },
    { day: "Sat", solved: 15, correct: 13 },
    { day: "Sun", solved: 9, correct: 8 },
  ];
  const mockCategory = [
    { name: "DSA", accuracy: 78, total: 20 },
    { name: "System Design", accuracy: 65, total: 12 },
    { name: "HR", accuracy: 90, total: 15 },
    { name: "Aptitude", accuracy: 72, total: 10 },
  ];
  const mockTimeline = [
    { index: 10, accuracy: 60 },
    { index: 20, accuracy: 65 },
    { index: 30, accuracy: 70 },
    { index: 40, accuracy: 73 },
    { index: 50, accuracy: 76 },
  ];

  const displayWeekly = hasMock ? mockWeekly : weeklyData;
  const displayCategory = hasMock ? mockCategory : categoryData;
  const displayTimeline = hasMock ? mockTimeline : accuracyTimeline;

  const firstName = profile?.full_name?.split(" ")[0] || "there";
  const greeting = new Date().getHours() < 12 ? "morning" : new Date().getHours() < 18 ? "afternoon" : "evening";

  if (loading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}>
        <h1 className="text-2xl font-semibold text-foreground">
          Good {greeting}, {firstName} 👋
        </h1>
        <p className="mt-1 text-muted-foreground">
          Here's your preparation overview
          {hasMock && <span className="ml-2 text-xs text-warning">(sample data — start solving to see yours)</span>}
        </p>
      </motion.div>

      {/* Stats grid */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
        <StatCard title="Questions Solved" value={hasMock ? 48 : totalSolved} icon={<CheckCircle2 className="h-5 w-5" />} trend={improvementScore !== null ? { value: Math.abs(improvementScore), positive: improvementScore >= 0 } : undefined} />
        <StatCard title="Accuracy" value={`${hasMock ? 76 : accuracy}%`} icon={<Target className="h-5 w-5" />} />
        <StatCard title="Daily Streak" value={profile?.daily_streak ?? 0} subtitle="days" icon={<Flame className="h-5 w-5" />} />
        <StatCard title="AI Chats" value={hasMock ? 12 : chatCount} icon={<MessageSquare className="h-5 w-5" />} />
        <StatCard title="Correct" value={hasMock ? 37 : correctCount} icon={<Trophy className="h-5 w-5" />} />
        <StatCard title="Points" value={profile?.total_points ?? 0} icon={<TrendingUp className="h-5 w-5" />} />
      </div>

      {/* Progress Milestones */}
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }} className="glass rounded-2xl p-6">
        <h3 className="mb-4 text-base font-semibold text-foreground">🏁 Progress Milestones</h3>
        <div className="relative">
          {/* Progress bar background */}
          <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-border" />
          <div className="space-y-0">
            {milestones.map((m, i) => {
              const reached = (hasMock ? 48 : totalSolved) >= m.target;
              const isNext = !reached && (i === 0 || (hasMock ? 48 : totalSolved) >= milestones[i - 1].target);
              const progress = isNext ? Math.min(100, Math.round(((hasMock ? 48 : totalSolved) / m.target) * 100)) : 0;

              return (
                <div key={m.target} className="relative flex items-center gap-4 py-2.5 pl-0">
                  {/* Checkpoint icon */}
                  <div className={`relative z-10 flex h-9 w-9 shrink-0 items-center justify-center rounded-full border-2 transition-all ${
                    reached
                      ? "border-success bg-success/10 text-success"
                      : isNext
                        ? "border-primary bg-primary/10 text-primary animate-pulse"
                        : "border-border bg-muted text-muted-foreground"
                  }`}>
                    {reached ? (
                      <CheckCircle2 className="h-4 w-4" />
                    ) : (
                      <span className="text-sm">{m.icon}</span>
                    )}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <p className={`text-sm font-medium ${reached ? "text-foreground" : "text-muted-foreground"}`}>
                        {m.label}
                      </p>
                      {reached && (
                        <span className="text-xs text-success font-medium">✓ Complete</span>
                      )}
                      {isNext && (
                        <span className="text-xs text-primary font-medium">{progress}%</span>
                      )}
                    </div>
                    {isNext && (
                      <Progress value={progress} className="mt-1.5 h-1.5" />
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </motion.div>

      {/* Charts row */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* Weekly Progress */}
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="glass rounded-2xl p-6">
          <h3 className="mb-4 text-base font-semibold text-foreground">📊 Weekly Progress</h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={displayWeekly}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="day" stroke="hsl(var(--muted-foreground))" fontSize={12} />
              <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
              <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: "8px", fontSize: "12px" }} />
              <Bar dataKey="solved" name="Solved" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
              <Bar dataKey="correct" name="Correct" fill="hsl(var(--success))" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Accuracy Over Time */}
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.25 }} className="glass rounded-2xl p-6">
          <h3 className="mb-4 text-base font-semibold text-foreground">📈 Accuracy Trend</h3>
          <ResponsiveContainer width="100%" height={250}>
            <AreaChart data={displayTimeline}>
              <defs>
                <linearGradient id="accGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="index" stroke="hsl(var(--muted-foreground))" fontSize={12} label={{ value: "Questions", position: "insideBottom", offset: -2, fontSize: 11 }} />
              <YAxis domain={[0, 100]} stroke="hsl(var(--muted-foreground))" fontSize={12} />
              <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: "8px", fontSize: "12px" }} />
              <Area type="monotone" dataKey="accuracy" stroke="hsl(var(--primary))" strokeWidth={2} fill="url(#accGrad)" dot={{ fill: "hsl(var(--primary))", r: 4 }} />
            </AreaChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Category Accuracy */}
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="glass rounded-2xl p-6">
          <h3 className="mb-4 text-base font-semibold text-foreground">🎯 Category Accuracy</h3>
          <div className="space-y-4">
            {(displayCategory.length > 0 ? displayCategory : mockCategory).map((cat) => (
              <div key={cat.name}>
                <div className="mb-1.5 flex items-center justify-between">
                  <span className="text-sm font-medium text-foreground">{cat.name}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-muted-foreground">{cat.total} Q</span>
                    <span className={`text-sm font-semibold ${cat.accuracy >= 70 ? "text-success" : cat.accuracy >= 50 ? "text-warning" : "text-destructive"}`}>
                      {cat.accuracy}%
                    </span>
                  </div>
                </div>
                <div className="h-2 overflow-hidden rounded-full bg-muted">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${cat.accuracy}%` }}
                    transition={{ duration: 0.8, delay: 0.3 }}
                    className={`h-full rounded-full ${
                      cat.accuracy >= 70
                        ? "bg-success"
                        : cat.accuracy >= 50
                          ? "bg-warning"
                          : "bg-destructive"
                    }`}
                  />
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Improvement Suggestions */}
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.35 }} className="glass rounded-2xl p-6">
          <div className="mb-4 flex items-center gap-2">
            <Lightbulb className="h-5 w-5 text-warning" />
            <h3 className="text-base font-semibold text-foreground">Improvement Tips</h3>
          </div>
          <div className="space-y-3">
            {suggestions.map((s, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.4 + i * 0.08 }}
                className={`rounded-xl border p-3.5 ${
                  s.type === "warning"
                    ? "border-warning/20 bg-warning/5"
                    : s.type === "success"
                      ? "border-success/20 bg-success/5"
                      : "border-primary/20 bg-primary/5"
                }`}
              >
                <div className="flex items-start gap-2.5">
                  {s.type === "warning" ? (
                    <TrendingDown className="mt-0.5 h-4 w-4 shrink-0 text-warning" />
                  ) : s.type === "success" ? (
                    <Zap className="mt-0.5 h-4 w-4 shrink-0 text-success" />
                  ) : (
                    <Lightbulb className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                  )}
                  <p className="text-sm text-foreground leading-relaxed">{s.text}</p>
                </div>
              </motion.div>
            ))}
          </div>
          <Button
            variant="outline"
            className="mt-4 w-full gap-2"
            onClick={() => navigate("/analytics")}
          >
            View Full Analytics
            <ArrowRight className="h-4 w-4" />
          </Button>
        </motion.div>
      </div>

      {/* Recent Activity Timeline */}
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }} className="glass rounded-2xl p-6">
        <h3 className="mb-5 text-base font-semibold text-foreground">⏱️ Recent Activity</h3>
        {recentActivity.length === 0 && !hasMock ? (
          <div className="py-8 text-center">
            <BookOpen className="mx-auto mb-2 h-8 w-8 text-muted-foreground" />
            <p className="text-muted-foreground">No activity yet. Start solving questions!</p>
            <Button variant="default" className="mt-3 gap-2" onClick={() => navigate("/questions")}>
              Go to Questions <ArrowRight className="h-4 w-4" />
            </Button>
          </div>
        ) : (
          <div className="relative">
            <div className="absolute left-[17px] top-2 bottom-2 w-px bg-border" />
            <div className="space-y-0">
              {(recentActivity.length > 0 ? recentActivity : [
                { id: "m1", is_correct: true, created_at: new Date(Date.now() - 3600000).toISOString(), time_taken_seconds: 45, question: { title: "Two Sum", category: "DSA", difficulty: "Easy" } },
                { id: "m2", is_correct: false, created_at: new Date(Date.now() - 7200000).toISOString(), time_taken_seconds: 120, question: { title: "Design a URL Shortener", category: "System Design", difficulty: "Medium" } },
                { id: "m3", is_correct: true, created_at: new Date(Date.now() - 10800000).toISOString(), time_taken_seconds: 30, question: { title: "Tell me about yourself", category: "HR", difficulty: "Easy" } },
                { id: "m4", is_correct: true, created_at: new Date(Date.now() - 14400000).toISOString(), time_taken_seconds: 90, question: { title: "Binary Search", category: "DSA", difficulty: "Easy" } },
                { id: "m5", is_correct: false, created_at: new Date(Date.now() - 18000000).toISOString(), time_taken_seconds: 180, question: { title: "LRU Cache", category: "DSA", difficulty: "Hard" } },
              ] as any[]).map((item: any, i: number) => (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, x: -8 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.45 + i * 0.05 }}
                  className="relative flex items-start gap-4 py-3 pl-0"
                >
                  <div className={`relative z-10 flex h-9 w-9 shrink-0 items-center justify-center rounded-full border-2 ${
                    item.is_correct
                      ? "border-success bg-success/10"
                      : "border-destructive bg-destructive/10"
                  }`}>
                    {item.is_correct ? (
                      <CheckCircle2 className="h-4 w-4 text-success" />
                    ) : (
                      <Circle className="h-4 w-4 text-destructive" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <p className="truncate text-sm font-medium text-foreground">
                        {item.question?.title || "Question"}
                      </p>
                      <span className={`shrink-0 rounded-md px-2 py-0.5 text-xs font-medium ${
                        item.question?.difficulty === "Easy"
                          ? "bg-success/10 text-success"
                          : item.question?.difficulty === "Medium"
                            ? "bg-warning/10 text-warning"
                            : "bg-destructive/10 text-destructive"
                      }`}>
                        {item.question?.difficulty || "—"}
                      </span>
                    </div>
                    <div className="mt-1 flex items-center gap-3 text-xs text-muted-foreground">
                      <span>{item.question?.category}</span>
                      {item.time_taken_seconds && (
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {item.time_taken_seconds}s
                        </span>
                      )}
                      <span>
                        {new Date(item.created_at).toLocaleTimeString("en", { hour: "2-digit", minute: "2-digit" })}
                      </span>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        )}
      </motion.div>
    </div>
  );
};

export default Dashboard;

import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Plus, Trash2, Loader2, FileQuestion } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";

interface Question {
  id: string;
  title: string;
  category: string;
  difficulty: string;
  type: string;
  created_at: string;
}

const AdminQuestions = () => {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  const [form, setForm] = useState({
    title: "", description: "", category: "DSA", difficulty: "Easy",
    type: "mcq", correct_answer: "", explanation: "",
    options: ["", "", "", ""],
  });

  const fetchQuestions = async () => {
    setLoading(true);
    const { data } = await supabase.from("questions").select("id, title, category, difficulty, type, created_at").order("created_at", { ascending: false });
    setQuestions(data || []);
    setLoading(false);
  };

  useEffect(() => { fetchQuestions(); }, []);

  const handleSave = async () => {
    if (!form.title || !form.description) {
      toast({ title: "Missing fields", description: "Title and description are required", variant: "destructive" });
      return;
    }
    setSaving(true);
    const payload: any = {
      title: form.title,
      description: form.description,
      category: form.category,
      difficulty: form.difficulty,
      type: form.type,
      correct_answer: form.correct_answer || null,
      explanation: form.explanation || null,
    };
    if (form.type === "mcq") {
      payload.options = form.options.filter(Boolean);
    }
    const { error } = await supabase.from("questions").insert(payload);
    if (error) {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Question added!" });
      setDialogOpen(false);
      setForm({ title: "", description: "", category: "DSA", difficulty: "Easy", type: "mcq", correct_answer: "", explanation: "", options: ["", "", "", ""] });
      fetchQuestions();
    }
    setSaving(false);
  };

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from("questions").delete().eq("id", id);
    if (error) {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Question deleted" });
      fetchQuestions();
    }
  };

  const difficultyColor = (d: string) => {
    switch (d.toLowerCase()) {
      case "easy": return "bg-success/10 text-success border-success/20";
      case "medium": return "bg-warning/10 text-warning border-warning/20";
      case "hard": return "bg-destructive/10 text-destructive border-destructive/20";
      default: return "";
    }
  };

  if (loading) {
    return <div className="flex min-h-[60vh] items-center justify-center"><Loader2 className="h-8 w-8 animate-spin text-muted-foreground" /></div>;
  }

  return (
    <div className="space-y-6">
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-foreground">Questions</h1>
          <p className="mt-1 text-muted-foreground">{questions.length} questions in the bank</p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2"><Plus className="h-4 w-4" />Add Question</Button>
          </DialogTrigger>
          <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-lg">
            <DialogHeader>
              <DialogTitle>Add New Question</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-2">
              <div className="space-y-2">
                <Label>Title</Label>
                <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Question title" />
              </div>
              <div className="space-y-2">
                <Label>Description</Label>
                <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Full question text" rows={3} />
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-2">
                  <Label>Category</Label>
                  <Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="DSA">DSA</SelectItem>
                      <SelectItem value="System Design">System Design</SelectItem>
                      <SelectItem value="HR">HR</SelectItem>
                      <SelectItem value="Aptitude">Aptitude</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Difficulty</Label>
                  <Select value={form.difficulty} onValueChange={(v) => setForm({ ...form, difficulty: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Easy">Easy</SelectItem>
                      <SelectItem value="Medium">Medium</SelectItem>
                      <SelectItem value="Hard">Hard</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Type</Label>
                  <Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="mcq">MCQ</SelectItem>
                      <SelectItem value="subjective">Subjective</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              {form.type === "mcq" && (
                <div className="space-y-2">
                  <Label>Options</Label>
                  {form.options.map((opt, i) => (
                    <Input
                      key={i}
                      value={opt}
                      onChange={(e) => {
                        const opts = [...form.options];
                        opts[i] = e.target.value;
                        setForm({ ...form, options: opts });
                      }}
                      placeholder={`Option ${i + 1}`}
                    />
                  ))}
                </div>
              )}
              <div className="space-y-2">
                <Label>Correct Answer</Label>
                <Input value={form.correct_answer} onChange={(e) => setForm({ ...form, correct_answer: e.target.value })} placeholder="Correct answer text" />
              </div>
              <div className="space-y-2">
                <Label>Explanation (optional)</Label>
                <Textarea value={form.explanation} onChange={(e) => setForm({ ...form, explanation: e.target.value })} placeholder="Why this is the correct answer" rows={2} />
              </div>
              <Button onClick={handleSave} disabled={saving} className="w-full">
                {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "Save Question"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </motion.div>

      <div className="glass overflow-hidden rounded-2xl">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border/50">
                <th className="px-4 py-3 text-left font-medium text-muted-foreground">Title</th>
                <th className="px-4 py-3 text-left font-medium text-muted-foreground">Category</th>
                <th className="px-4 py-3 text-left font-medium text-muted-foreground">Difficulty</th>
                <th className="px-4 py-3 text-left font-medium text-muted-foreground">Type</th>
                <th className="px-4 py-3 text-right font-medium text-muted-foreground">Actions</th>
              </tr>
            </thead>
            <tbody>
              {questions.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-4 py-12 text-center">
                    <FileQuestion className="mx-auto mb-2 h-8 w-8 text-muted-foreground" />
                    <p className="text-muted-foreground">No questions yet. Add your first one!</p>
                  </td>
                </tr>
              ) : questions.map((q) => (
                <tr key={q.id} className="border-b border-border/30 transition-colors hover:bg-accent/20">
                  <td className="max-w-[240px] truncate px-4 py-3 font-medium text-foreground">{q.title}</td>
                  <td className="px-4 py-3"><Badge variant="outline">{q.category}</Badge></td>
                  <td className="px-4 py-3"><span className={`rounded-md border px-2 py-0.5 text-xs font-medium ${difficultyColor(q.difficulty)}`}>{q.difficulty}</span></td>
                  <td className="px-4 py-3 text-muted-foreground capitalize">{q.type}</td>
                  <td className="px-4 py-3 text-right">
                    <Button size="sm" variant="ghost" onClick={() => handleDelete(q.id)} className="text-destructive hover:text-destructive">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AdminQuestions;

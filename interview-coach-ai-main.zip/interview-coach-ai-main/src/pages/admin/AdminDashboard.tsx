import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Users, FileQuestion, MessageSquare, TrendingUp, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

const AdminDashboard = () => {
  const [stats, setStats] = useState({ users: 0, questions: 0, answers: 0, chats: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      const [profiles, questions, answers, chats] = await Promise.all([
        supabase.from("profiles").select("id", { count: "exact", head: true }),
        supabase.from("questions").select("id", { count: "exact", head: true }),
        supabase.from("user_answers").select("id", { count: "exact", head: true }),
        supabase.from("chat_history").select("id", { count: "exact", head: true }),
      ]);
      setStats({
        users: profiles.count || 0,
        questions: questions.count || 0,
        answers: answers.count || 0,
        chats: chats.count || 0,
      });
      setLoading(false);
    };
    fetchStats();
  }, []);

  if (loading) {
    return <div className="flex min-h-[60vh] items-center justify-center"><Loader2 className="h-8 w-8 animate-spin text-muted-foreground" /></div>;
  }

  const cards = [
    { label: "Total Users", value: stats.users, icon: Users, color: "bg-primary/10 text-primary" },
    { label: "Questions", value: stats.questions, icon: FileQuestion, color: "bg-success/10 text-success" },
    { label: "Answers Submitted", value: stats.answers, icon: TrendingUp, color: "bg-warning/10 text-warning" },
    { label: "Chat Messages", value: stats.chats, icon: MessageSquare, color: "bg-accent text-accent-foreground" },
  ];

  return (
    <div className="space-y-8">
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-2xl font-semibold text-foreground">Admin Overview</h1>
        <p className="mt-1 text-muted-foreground">Platform-wide statistics and management</p>
      </motion.div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {cards.map((card, i) => (
          <motion.div
            key={card.label}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
            className="glass rounded-2xl p-5"
          >
            <div className="flex items-center gap-3">
              <div className={`flex h-10 w-10 items-center justify-center rounded-xl ${card.color}`}>
                <card.icon className="h-5 w-5" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">{card.label}</p>
                <p className="text-2xl font-semibold text-foreground">{card.value}</p>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default AdminDashboard;

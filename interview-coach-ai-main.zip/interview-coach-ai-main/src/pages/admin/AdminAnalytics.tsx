import React, { useEffect, useState, useMemo } from "react";
import { motion } from "framer-motion";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line,
} from "recharts";
import { Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

const AdminAnalytics = () => {
  const [answers, setAnswers] = useState<any[]>([]);
  const [dailyStats, setDailyStats] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetch = async () => {
      const [a, d] = await Promise.all([
        supabase.from("user_answers").select("is_correct, created_at, question_id").order("created_at"),
        supabase.from("daily_stats").select("*").order("date"),
      ]);
      setAnswers(a.data || []);
      setDailyStats(d.data || []);
      setLoading(false);
    };
    fetch();
  }, []);

  const dailyActivity = useMemo(() => {
    const map = new Map<string, { total: number; correct: number }>();
    answers.forEach((a) => {
      const d = new Date(a.created_at).toISOString().slice(0, 10);
      if (!map.has(d)) map.set(d, { total: 0, correct: 0 });
      const e = map.get(d)!;
      e.total++;
      if (a.is_correct) e.correct++;
    });
    return Array.from(map.entries())
      .sort(([a], [b]) => a.localeCompare(b))
      .slice(-14)
      .map(([date, d]) => ({
        date: new Date(date).toLocaleDateString("en", { month: "short", day: "numeric" }),
        answers: d.total,
        accuracy: d.total > 0 ? Math.round((d.correct / d.total) * 100) : 0,
      }));
  }, [answers]);

  const correctVsWrong = useMemo(() => {
    const correct = answers.filter((a) => a.is_correct).length;
    return [
      { name: "Correct", value: correct, color: "hsl(var(--success))" },
      { name: "Incorrect", value: answers.length - correct, color: "hsl(var(--destructive))" },
    ];
  }, [answers]);

  if (loading) {
    return <div className="flex min-h-[60vh] items-center justify-center"><Loader2 className="h-8 w-8 animate-spin text-muted-foreground" /></div>;
  }

  return (
    <div className="space-y-8">
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-2xl font-semibold text-foreground">Platform Analytics</h1>
        <p className="mt-1 text-muted-foreground">Aggregated stats across all users</p>
      </motion.div>

      <div className="grid gap-6 lg:grid-cols-2">
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="glass rounded-2xl p-6">
          <h3 className="mb-4 text-base font-semibold text-foreground">Daily Answer Volume</h3>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={dailyActivity}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="date" stroke="hsl(var(--muted-foreground))" fontSize={11} />
              <YAxis stroke="hsl(var(--muted-foreground))" fontSize={11} />
              <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: "8px", fontSize: "12px" }} />
              <Bar dataKey="answers" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="glass rounded-2xl p-6">
          <h3 className="mb-4 text-base font-semibold text-foreground">Platform Accuracy Trend</h3>
          <ResponsiveContainer width="100%" height={280}>
            <LineChart data={dailyActivity}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="date" stroke="hsl(var(--muted-foreground))" fontSize={11} />
              <YAxis domain={[0, 100]} stroke="hsl(var(--muted-foreground))" fontSize={11} />
              <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: "8px", fontSize: "12px" }} />
              <Line type="monotone" dataKey="accuracy" stroke="hsl(var(--primary))" strokeWidth={2} dot={{ fill: "hsl(var(--primary))", r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="glass rounded-2xl p-6">
          <h3 className="mb-4 text-base font-semibold text-foreground">Correct vs Incorrect</h3>
          <ResponsiveContainer width="100%" height={280}>
            <PieChart>
              <Pie data={correctVsWrong} cx="50%" cy="50%" innerRadius={60} outerRadius={100} dataKey="value" label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}>
                {correctVsWrong.map((entry, i) => <Cell key={i} fill={entry.color} />)}
              </Pie>
              <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: "8px", fontSize: "12px" }} />
            </PieChart>
          </ResponsiveContainer>
        </motion.div>
      </div>
    </div>
  );
};

export default AdminAnalytics;

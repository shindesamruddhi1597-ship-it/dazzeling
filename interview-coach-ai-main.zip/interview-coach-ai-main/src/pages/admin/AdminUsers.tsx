import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Users, Shield, ShieldOff, Loader2, Search } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

interface UserProfile {
  id: string;
  user_id: string;
  full_name: string | null;
  username: string | null;
  total_points: number;
  daily_streak: number;
  created_at: string;
  isAdmin?: boolean;
}

const AdminUsers = () => {
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [toggling, setToggling] = useState<string | null>(null);
  const { toast } = useToast();

  const fetchUsers = async () => {
    setLoading(true);
    const { data: profiles } = await supabase
      .from("profiles")
      .select("id, user_id, full_name, username, total_points, daily_streak, created_at")
      .order("created_at", { ascending: false });

    const { data: roles } = await supabase
      .from("user_roles")
      .select("user_id, role")
      .eq("role", "admin");

    const adminIds = new Set(roles?.map((r) => r.user_id) || []);
    setUsers(
      (profiles || []).map((p) => ({ ...p, isAdmin: adminIds.has(p.user_id) }))
    );
    setLoading(false);
  };

  useEffect(() => { fetchUsers(); }, []);

  const toggleAdmin = async (profile: UserProfile) => {
    setToggling(profile.user_id);
    try {
      if (profile.isAdmin) {
        await supabase.from("user_roles").delete().eq("user_id", profile.user_id).eq("role", "admin");
        toast({ title: "Admin role removed", description: `${profile.full_name || profile.username || "User"} is no longer an admin.` });
      } else {
        await supabase.from("user_roles").insert({ user_id: profile.user_id, role: "admin" });
        toast({ title: "Admin role granted", description: `${profile.full_name || profile.username || "User"} is now an admin.` });
      }
      await fetchUsers();
    } catch (error: any) {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    }
    setToggling(null);
  };

  const filtered = users.filter((u) => {
    const q = search.toLowerCase();
    return !q || (u.full_name?.toLowerCase().includes(q)) || (u.username?.toLowerCase().includes(q));
  });

  if (loading) {
    return <div className="flex min-h-[60vh] items-center justify-center"><Loader2 className="h-8 w-8 animate-spin text-muted-foreground" /></div>;
  }

  return (
    <div className="space-y-6">
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-2xl font-semibold text-foreground">User Management</h1>
        <p className="mt-1 text-muted-foreground">{users.length} registered users</p>
      </motion.div>

      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input placeholder="Search users..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-10" />
      </div>

      <div className="glass overflow-hidden rounded-2xl">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border/50">
                <th className="px-4 py-3 text-left font-medium text-muted-foreground">User</th>
                <th className="px-4 py-3 text-left font-medium text-muted-foreground">Points</th>
                <th className="px-4 py-3 text-left font-medium text-muted-foreground">Streak</th>
                <th className="px-4 py-3 text-left font-medium text-muted-foreground">Joined</th>
                <th className="px-4 py-3 text-left font-medium text-muted-foreground">Role</th>
                <th className="px-4 py-3 text-right font-medium text-muted-foreground">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((u) => (
                <tr key={u.id} className="border-b border-border/30 transition-colors hover:bg-accent/20">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <div className="flex h-8 w-8 items-center justify-center rounded-full bg-muted">
                        <Users className="h-4 w-4 text-muted-foreground" />
                      </div>
                      <div>
                        <p className="font-medium text-foreground">{u.full_name || "—"}</p>
                        <p className="text-xs text-muted-foreground">{u.username || "no username"}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-foreground">{u.total_points}</td>
                  <td className="px-4 py-3 text-foreground">{u.daily_streak}d</td>
                  <td className="px-4 py-3 text-muted-foreground">{new Date(u.created_at).toLocaleDateString()}</td>
                  <td className="px-4 py-3">
                    {u.isAdmin ? (
                      <Badge variant="destructive" className="text-xs">Admin</Badge>
                    ) : (
                      <Badge variant="secondary" className="text-xs">User</Badge>
                    )}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <Button
                      size="sm"
                      variant={u.isAdmin ? "outline" : "default"}
                      disabled={toggling === u.user_id}
                      onClick={() => toggleAdmin(u)}
                      className="gap-1.5"
                    >
                      {toggling === u.user_id ? (
                        <Loader2 className="h-3 w-3 animate-spin" />
                      ) : u.isAdmin ? (
                        <><ShieldOff className="h-3 w-3" /> Revoke</>
                      ) : (
                        <><Shield className="h-3 w-3" /> Make Admin</>
                      )}
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AdminUsers;

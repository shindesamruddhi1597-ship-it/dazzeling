import { Link, useLocation } from "react-router-dom";
import { BookOpen } from "lucide-react";
import { cn } from "@/lib/utils";

const AuthHeader = () => {
  const { pathname } = useLocation();

  return (
    <header className="fixed top-0 left-0 right-0 z-50 border-b border-border/50 bg-background/80 backdrop-blur-xl">
      <div className="mx-auto flex h-14 max-w-7xl items-center justify-between px-6">
        <Link to="/login" className="flex items-center gap-2.5">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg gradient-primary">
            <BookOpen className="h-4 w-4 text-primary-foreground" />
          </div>
          <span className="text-base font-semibold text-foreground">InterviewPrep</span>
        </Link>

        <nav className="flex items-center gap-1 rounded-full border border-border/50 bg-muted/50 p-1">
          <Link
            to="/login"
            className={cn(
              "rounded-full px-4 py-1.5 text-sm font-medium transition-all",
              pathname === "/login"
                ? "bg-background text-foreground shadow-sm"
                : "text-muted-foreground hover:text-foreground"
            )}
          >
            Sign In
          </Link>
          <Link
            to="/signup"
            className={cn(
              "rounded-full px-4 py-1.5 text-sm font-medium transition-all",
              pathname === "/signup"
                ? "bg-background text-foreground shadow-sm"
                : "text-muted-foreground hover:text-foreground"
            )}
          >
            Sign Up
          </Link>
        </nav>
      </div>
    </header>
  );
};

export default AuthHeader;
